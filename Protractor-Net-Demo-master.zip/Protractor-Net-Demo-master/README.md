﻿__Protractor .NET Example__

Some NUnit tests using [Protractor.NET](https://github.com/bbaia/protractor-net). The tests run against the [Protractor Demo Calculator](http://juliemr.github.io/protractor-demo/).

* **BasicTests.cs** - Basic tests
* **PageObjectTests.cs** - Tests using page objects
* **SimpleMath.feature and SimpleMathSteps.cs** - Specflow/Gherkin tests